1.The sensors data we get by subscribing to topic via MqQTT by running "Mqttsubscriber.java" and is stored in text file named as "nt.txt".
2.Then we compute power using this data and check for threshold by running "Mqttpublisher.java"
3.Create empty text file "nt.txt".
4.Please change the directory in code where text file you are putting with appropriate name as "nt.txt" as this is mentioned in the code.