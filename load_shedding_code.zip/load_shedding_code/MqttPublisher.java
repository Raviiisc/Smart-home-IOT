import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions; //importing mqtt libraries for establishing connection
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.util.*;

//import java.nio.file.Files;
//import java.nio.file.Path;
//import java.io.IOException;
import java.nio.file.*;
import java.io.*;
import java.lang.Math;
public class MqttPublisher {
	  public static String readFileAsString(String fileName)throws Exception
	  {
	    String data = "";
	    data = new String(Files.readAllBytes(Paths.get(fileName)));
	    return data;
	  }

    public static void main(String[] args) throws Exception {
    	
    	String data = readFileAsString("C:\\Users\\rohit\\Desktop\\nt.txt"); //writing sensors data to text file
    	//System.out.println(volt);
    	Scanner scanner = new Scanner(new File("C:\\Users\\rohit\\Desktop\\nt.txt"));
    	float [] tall = new float [4];
    	int i = 0;
    	while(scanner.hasNextFloat())
    	{
    	tall[i++] = scanner.nextFloat();
    	}
    	float load = 0;
    	for(int j=0;j<tall.length;j++)
    		load = load + ((tall[j]*tall[j])/470);
    	for(int j=0;j<tall.length;j++)
    		System.out.println(tall[j]);
    	System.out.println(load);
    	//Topic name 
        String topic        = "led1";
       // MqttSubscriber a = new MqttSubscriber();
        //data to be send
        String  content;
        if(Math.abs(load - 0.045980204) < 0.1) {
        	content      = "off1";
        }else {
        	content      = "EE";
        }
        
        //String content = "off1";
        int qos             = 0;
        String broker = "tcp://broker.emqx.io:1883";
        String clientId     = "JavaSample";
        MemoryPersistence persistence = new MemoryPersistence();

        try {
            MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);
            System.out.println("Connecting to broker: "+broker);
            sampleClient.connect(connOpts);
            System.out.println("Connected to broker");  //establishing connection
            System.out.println("Publishing message:"+content);
            MqttMessage message = new MqttMessage(content.getBytes());
            message.setQos(qos);
            sampleClient.publish(topic, message);
            System.out.println("Message published");
            sampleClient.disconnect();
            sampleClient.close();
            System.exit(0);
            } catch(MqttException me) {
            System.out.println("reason "+me.getReasonCode());
            System.out.println("msg "+me.getMessage());
            System.out.println("loc "+me.getLocalizedMessage());
            System.out.println("cause "+me.getCause());
            System.out.println("excep "+me);
            me.printStackTrace();
        }
    }
}