import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;  //importing mqtt libraries
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import java.nio.file.Files;
import java.nio.file.Path;
import java.io.* ;
public class MqttSubscriber implements MqttCallback  {

	
	private static final String brokerUrl ="tcp://broker.emqx.io:1883";
	/** The client id. */
	private static final String clientId = "clientId";

	/** The topic. */
	private static final String topic = "test_channel";

	public static void main(String[] args) {

		System.out.println("Subscriber running");
		new MqttSubscriber().subscribe(topic);

	}

	public void subscribe(String topic) {
		
		MemoryPersistence persistence = new MemoryPersistence();

		try
		{

			MqttClient sampleClient = new MqttClient(brokerUrl, clientId, persistence);
			MqttConnectOptions connOpts = new MqttConnectOptions();
			connOpts.setCleanSession(true);

			System.out.println("checking");
			System.out.println("Mqtt Connecting to broker: " + brokerUrl);

			sampleClient.connect(connOpts);
			System.out.println("Mqtt Connected");

			sampleClient.setCallback(this);
			sampleClient.subscribe(topic);

			System.out.println("Subscribed");
			System.out.println("Listening");

		} catch (MqttException me) {
			System.out.println(me);
		}
	}

	 //Called when the client lost the connection to the broker
	public void connectionLost(Throwable arg0) {
		
	}

	//Called when a outgoing publish is complete
	public void deliveryComplete(IMqttDeliveryToken arg0) {

	}

	public void messageArrived(String topic, MqttMessage message) throws Exception {

		System.out.println("| Topic:" + topic);
		//public String value = message.toString() ;
		//Path fileName = Path.of("C:\\Users\\rohit\\Desktop\\nt.txt");
		//Files.writeString(fileName,message.toString() );
		  try{
			  FileWriter fstream = new FileWriter("C:\\Users\\rohit\\Desktop\\nt.txt",true);
			  BufferedWriter out = new BufferedWriter(fstream);
			  out.write( message + "\n");
			  out.close();
		  }catch (Exception e){
			 System.err.println("Error while writing to file: " +
		          e.getMessage());
		  }
		System.out.println("| Message: " +message.toString()); //printing the subscribed message
		System.out.println("-------------------------------------------------");

	}
   
	public MqttMessage mesg;
	
}
